// Imagens da galeria (mantida da fase 2)
const imagens = [
  "https://previews.dropbox.com/p/thumb/ACq-1shG0fqrIi_83n68WZXine0HNj0epbiibjgMWOZjSDGye_yJNLZyE0p84yC7b5qJfR9eIlaikwYB235niXN2RMFqqVyOo_yp-WeHQ74kb_gS-mAoO6oUwQvQoPzEDcxffECwN8FvEI7JoE2_Ze2VV7kePOmgRfRhq9dQ8OK0HDXlxK4PYd-w6MLs0h-1mWtZfC-QwDLlkY-MdZxAhgJtX3cxWHYjIbqkxEwCsl0OD40-22ii28B9VtG2zAUoqw6q0iVHXRwNtNX8pP7ymzhBYJkXVfQu8btoAUpZbGp72Yu69dY-07ad6U2nojFQuegMzBOZOjoIm0dFu-FqCCIw89XeAobfIPamxEfsBRhPAg/p.jpeg",
  "https://previews.dropbox.com/p/thumb/ACo2zfLD9eVlPCRRWCcBrnPNFKckKBuBR7lcwMPzk9-YMg15RUuBp9stQo7paACPl5W5ujCtcjFtSJr_zf60ncAoPgVYKh33d84i7ESv3s39EQiEaSdbiK8aYf-GqxGcZxMFf1Aj6xlFYHmALjMBlHXS5OZnO2HJghxre3uPhv-D_KiHWSnsnR-s5Y2Pq0-H8nps9nnOVbkNbl3RhKWXW4PgY1ByJBuEk1b8EBASQgKPJSXV6GJhR7_kjPy3HfZHihzmvRDTqOq4vKwUQDIECVbkDPo34sNg1Kku7V84jjene6478Yf6yXFK1EwTMlzuF-iZx43ARw28TGttqmEYcvQy/p.jpeg?is_prewarmed=true",
  "https://previews.dropbox.com/p/thumb/ACpYxG9Iu_ZUtk3N73KOdFQcwEM807AmQfR_B_Jqy5btkoyD964rEH_6SWFyyh40OLlq-GxhAHflRkeIpcxRSpoOlagyxniFdBQFWNNTjXuNW-svDY4zBLvaex0wRu4ulYcr854WHPj77P--Caa1PC5bIbwXvjzg_Lf90ASQnn6p2blj8dM1O4Agr2VgRpzk0Wen4YhlHb6Ip8itcHZovrD8k7NDD-cBU4Ys-G3D8HQqSX0TQxZlC52PqYsVpGta5UqADveULygQkYhAynp2du1iZVAAuGnce7MKXDxLKvMiljjhF_H8YJ7pd42rML3K2gyL7wi01elPbNIUlucR2hvj/p.jpeg?is_prewarmed=true"
];
let indice = 0;
function trocarImagem(direcao) {
  indice = (indice + direcao + imagens.length) % imagens.length;
  document.getElementById("profile-image").src = imagens[indice];
}

// Adicionar nova UC
function adicionarUC() {
  const novaUC = prompt("Digite o nome da nova UC:");
  if (novaUC) {
    const ul = document.querySelector(".ucs ul");
    const li = document.createElement("li");

    const span = document.createElement("span");
    span.textContent = novaUC;

    const btnUp = document.createElement("button");
    btnUp.textContent = "↑";
    btnUp.onclick = () => moverParaCima(li);

    const btnDown = document.createElement("button");
    btnDown.textContent = "↓";
    btnDown.onclick = () => moverParaBaixo(li);

    li.appendChild(span);
    li.appendChild(btnUp);
    li.appendChild(btnDown);

    ul.appendChild(li);
  }
}

// Mover UC para cima
function moverParaCima(item) {
  const anterior = item.previousElementSibling;
  if (anterior) {
    item.parentNode.insertBefore(item, anterior);
  }
}

// Mover UC para baixo
function moverParaBaixo(item) {
  const proximo = item.nextElementSibling;
  if (proximo) {
    item.parentNode.insertBefore(proximo, item);
  }
}

// Validação de CPF
function validarCPF(campo) {
  const regex = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/;
  const cpf = campo.value.trim();

  if (!regex.test(cpf)) {
    alert("CPF inválido! Use o formato 000.000.000-00");
    campo.focus();
    campo.style.borderColor = "red";
  } else {
    campo.style.borderColor = ""; // limpa estilo se estiver válido
  }
}


// Validação de E-mail
function validarEmail(campo) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!regex.test(campo.value)) {
    alert("E-mail inválido!");
    campo.focus();
  }
}

// Adicionar nova informação ao perfil pessoal
function adicionarInfoPessoal() {
  const novaInfo = document.getElementById("nova-info").value.trim();
  if (novaInfo !== "") {
    const container = document.getElementById("info-pessoal-extra");
    const p = document.createElement("p");
    p.textContent = novaInfo;
    container.appendChild(p);
    document.getElementById("nova-info").value = "";
  }
}
